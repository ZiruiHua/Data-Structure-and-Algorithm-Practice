import java.util.Arrays;
import java.util.HashMap;

public class Turing {

    final int MAXLENGTH = 99;
    char[] inTape;
    int state_num;
    int header = 0;
    int currentStateIndex = 0;
    int haltStateIndex;
    //ArrayList<State> states = new ArrayList<>();
    HashMap<Integer, State> map= new HashMap<>();


    public Turing(int state_num) {
        this.state_num = state_num;
        haltStateIndex = state_num - 1;
    }

    public void addState(State state) {
        //states.add(state);
        map.put(state.getIndex(), state);
    }

    public String execute(String input) {
        inTape = new char[MAXLENGTH];
        // fill inTape array with 'B'
        Arrays.fill(inTape, 'B');
        inTape[0] = 'S';
        for (int i = 1; i < input.length()+1; i++) {
            inTape[i] = input.charAt(i-1);
        }
        // && header >= 0 是后加的
        while (currentStateIndex != haltStateIndex && header >= 0) {
            State currentState = map.get(currentStateIndex);
            char currentCharacter = inTape[header];
            // find proper transition
            Transition t = currentState.getStateMap().get(currentCharacter);
            inTape[header] = t.getWriteToTape();
            switch (t.getDirection()) {
                case 'l':
                    header--;
                    break;
                case 'r':
                    header++;
                    break;
            }
            currentStateIndex = t.getNextState();
        }

        return String.valueOf(inTape);
    }

}
