public class TuringDecider {
    public static void main(String args[]) {
        Turing machine1 = new Turing(8);

        State s0 = new State(0);
        s0.addTransition(new Transition('0', 'X', Transition.RIGHT, 1));
        // encounter a Y
        s0.addTransition(new Transition('Y', 'Y', Transition.RIGHT, 3));
        // encounter 'S' that I used to identify the beginning of the String
        s0.addTransition(new Transition('S', 'S', Transition.RIGHT, 0));

        // encounter a 1 at first ex 100 go to right to find the first B
        s0.addTransition(new Transition('1', '1', Transition.RIGHT, 6));
        // 0101 B...
        s0.addTransition(new Transition('B', 'B', Transition.LEFT, 4));


        State s1 = new State(1);
        // leftmost 0 -> X
        s1.addTransition(new Transition('0', '0', Transition.RIGHT, 1));
        // encounter 1 then 1 -> Y
        s1.addTransition(new Transition('1', 'Y', Transition.LEFT, 2));
        //
        s1.addTransition(new Transition('Y', 'Y', Transition.RIGHT, 1));

        // fail condition  X X X Y Y B B...
        s1.addTransition(new Transition('B', 'B', Transition.LEFT, 4));

        State s2 = new State(2);
        // find leftmost 0
        s2.addTransition(new Transition('0', '0', Transition.LEFT, 2));
        // find that 0 back
        s2.addTransition(new Transition('X', 'X', Transition.RIGHT, 0));
        //
        s2.addTransition(new Transition('Y', 'Y', Transition.LEFT, 2));


        State s3 = new State(3);
        // find rightmost Y
        s3.addTransition(new Transition('Y', 'Y', Transition.RIGHT, 3));
        // find that Y end Accept
        s3.addTransition(new Transition('B', 'B', Transition.LEFT, 5));

        // another fail condition X Y 1 B B...
        s3.addTransition(new Transition('1', 'B', Transition.LEFT, 4));

        // another fail condition X Y 0 1 ...
        s3.addTransition(new Transition('0', '0', Transition.RIGHT, 6));


        // receive
        State s4 = new State(4);
        s4.addTransition(new Transition('Y', 'B', Transition.LEFT, 4));
        s4.addTransition(new Transition('X', 'B', Transition.LEFT, 4));
        s4.addTransition(new Transition('1', 'B', Transition.LEFT, 4));
        s4.addTransition(new Transition('0', 'B', Transition.LEFT, 4));

        // write 0 since refuse
        s4.addTransition(new Transition('S', '0', Transition.RIGHT, 7));

        // accept
        State s5 = new State(5);
        s5.addTransition(new Transition('Y', 'B', Transition.LEFT, 5));
        s5.addTransition(new Transition('X', 'B', Transition.LEFT, 5));
        s5.addTransition(new Transition('1', 'B', Transition.LEFT, 5));
        s5.addTransition(new Transition('0', 'B', Transition.LEFT, 5));

        // write 1 since accept
        s5.addTransition(new Transition('S', '1', Transition.RIGHT, 7));

        // already identify refuse but has number afterward
        State s6 = new State(6);
        s6.addTransition(new Transition('0', '0', Transition.RIGHT, 6));
        s6.addTransition(new Transition('1', '1', Transition.RIGHT, 6));
        s6.addTransition(new Transition('X', 'X', Transition.RIGHT, 6));
        s6.addTransition(new Transition('Y', 'Y', Transition.RIGHT, 6));
        // find B end to state 4
        s6.addTransition(new Transition('B', 'B', Transition.LEFT, 4));

        machine1.addState(s0);
        machine1.addState(s1);
        machine1.addState(s2);
        machine1.addState(s3);
        machine1.addState(s4);
        machine1.addState(s5);
        machine1.addState(s6);

        String inTape = "10101";

        System.out.println(inTape);

        String outTape = machine1.execute(inTape);

        System.out.println(outTape);
    }
}
